'use strict';
// Gera a pasta www/ (interface + backend em WebAssembly) que o Capacitor empacota no APK.
const fs = require('fs'), path = require('path');
const esbuild = require('esbuild');
const raiz = path.join(__dirname, '..'), www = path.join(raiz, 'www'), m = (...p) => path.join(raiz, 'src', 'mobile', ...p);
const nm = (p) => path.join(raiz, 'node_modules', p);

const plugin = {
  name: 'aulapro-mobile',
  setup(b) {
    // O extractor do computador (pdf-parse/Tesseract) é substituído pela versão leve do Android.
    b.onResolve({ filter: /^\.\/extract$/ }, () => ({ path: m('extract-mobile.js') }));
    b.onResolve({ filter: /^(fs|node:fs)$/ }, () => ({ path: m('fs-shim.js') }));
    b.onResolve({ filter: /^(path|node:path)$/ }, () => ({ path: m('path-shim.js') }));
    b.onResolve({ filter: /^(crypto|node:crypto)$/ }, () => ({ path: m('crypto-shim.js') }));
    b.onResolve({ filter: /^electron$/ }, () => ({ path: m('electron-shim.js') }));
    b.onResolve({ filter: /^better-sqlite3$/ }, () => ({ path: m('sqlite-adapter.js') }));
    // pdfkit: versão "standalone" (inclui as fontes) para o navegador/WebView
    b.onResolve({ filter: /^pdfkit$/ }, () => (fs.existsSync(nm('pdfkit/js/pdfkit.standalone.js')) ? { path: nm('pdfkit/js/pdfkit.standalone.js') } : undefined));
  },
};

(async () => {
  fs.rmSync(www, { recursive: true, force: true }); fs.mkdirSync(www, { recursive: true });
  await esbuild.build({
    entryPoints: [m('entry.js')], bundle: true, minify: true, format: 'iife', platform: 'browser', target: 'es2020',
    outfile: path.join(www, 'backend.js'), plugins: [plugin], external: ['node:sqlite'], logLevel: 'info',
    define: { 'process.env.AULAPRO_TESTE': '""', global: 'globalThis' },
    alias: { buffer: nm('buffer') },
  });
  for (const f of fs.readdirSync(path.join(raiz, 'src', 'renderer'))) fs.copyFileSync(path.join(raiz, 'src', 'renderer', f), path.join(www, f));
  fs.copyFileSync(nm('sql.js/dist/sql-wasm.wasm'), path.join(www, 'sql-wasm.wasm'));
  let html = fs.readFileSync(path.join(www, 'index.html'), 'utf8');
  html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/,
    '<meta http-equiv="Content-Security-Policy" content="default-src \'self\' https://localhost; img-src \'self\' data: blob:; style-src \'self\' \'unsafe-inline\'; script-src \'self\' \'wasm-unsafe-eval\'; connect-src \'self\' https: data: blob:; media-src \'self\' blob:">');
  html = html.replace('<script src="core.js">', '<script src="backend.js"></script>\n<script src="core.js">');
  fs.writeFileSync(path.join(www, 'index.html'), html);
  console.log('www/ pronto');
})().catch((e) => { console.error(e); process.exit(1); });
