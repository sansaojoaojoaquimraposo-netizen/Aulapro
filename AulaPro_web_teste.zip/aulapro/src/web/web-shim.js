'use strict';
// Ponte do navegador para o servidor de teste (substitui o preload do Electron).
(function () {
  const ESCOLHER = { // canais que no programa abrem a janela "escolher ficheiro"
    'ficheiros.carregar': { accept: '.pdf,.png,.jpg,.jpeg,.txt,.docx', multiplo: true, vazio: [] },
    'alunos.importar': { accept: '.csv,.txt', vazio: 0 },
    'biblioteca.adicionar': { accept: '.pdf', vazio: null },
    'ficheiro.escolher': { accept: 'image/png,image/jpeg', vazio: null },
  };
  const escolher = (accept, multiplo) => new Promise((res) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = accept; i.multiple = !!multiplo; i.style.display = 'none'; document.body.appendChild(i);
    i.addEventListener('change', () => { const f = [...i.files]; i.remove(); res(f); }); i.addEventListener('cancel', () => { i.remove(); res([]); }); i.click();
  });
  const enviar = async (f) => (await (await fetch('/upload', { method: 'POST', headers: { 'x-nome': encodeURIComponent(f.name) }, body: f })).json()).caminho;
  const descarregar = (f) => { const a = document.createElement('a'); a.href = f.url; a.download = f.nome; document.body.appendChild(a); a.click(); a.remove(); };
  window.api = {
    plataforma: 'web', aoReceber() {},
    async invocar(canal, ...args) {
      let uploads = [];
      const e = ESCOLHER[canal];
      if (e) { const f = await escolher(e.accept, e.multiplo); if (!f.length) return e.vazio; uploads = await Promise.all(f.map(enviar)); }
      const r = await (await fetch('/rpc', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ canal, args, uploads }) })).json();
      if (!r.ok) throw new Error(r.erro);
      (r.ficheiros || []).forEach(descarregar);
      (r.abrir || []).forEach((u) => window.open(u, '_blank', 'noopener'));
      // As mensagens do programa dizem "guardado em <caminho>": no navegador o ficheiro vai para a pasta de Transferências.
      if (r.ficheiros && r.ficheiros.length && typeof r.data === 'string') return r.ficheiros[0].nome + ' (na pasta Transferências)';
      return r.data;
    },
  };
})();
