'use strict';
// AulaPro — MODO WEB DE TESTE.
// Corre os MESMOS módulos do programa (db, auth, calc, ai, extract, exporters, ipc) num servidor local e
// abre a interface no navegador. Serve para testar todas as funcionalidades antes de empacotar.
// Uploads vão do navegador para o servidor; exportações (PDF/PPTX/DOCX/CSV) descarregam pelo navegador.
// NÃO é para publicar na internet: não tem HTTPS próprio nem protecção contra utilizadores concorrentes.
process.env.AULAPRO_TESTE = '1'; // permite usar node:sqlite se o better-sqlite3 não estiver instalado
const Module = require('module'), http = require('http'), fs = require('fs'), path = require('path');

const PORTA = Number(process.env.PORT) || 5177;
const DADOS = path.resolve(process.env.AULAPRO_DADOS || path.join(__dirname, '..', '..', 'dados-web'));
const EXPORT = path.join(DADOS, 'exportacoes'), UPLOADS = path.join(DADOS, 'uploads');
for (const d of [DADOS, EXPORT, UPLOADS]) fs.mkdirSync(d, { recursive: true });

// ---------- 'electron' simulado no servidor ----------
const handlers = {};
let pedido = null; // estado do pedido RPC em curso (um utilizador de cada vez)
const novoPedido = (uploads) => ({ uploads, exportar: new Map(), pastas: [], abrir: [] });
const registar = (p, nome) => { pedido.exportar.set(p, nome || path.basename(p).replace(/^\d+_/, '')); };
const electron = {
  ipcMain: { handle: (c, f) => { handlers[c] = f; } },
  dialog: {
    async showSaveDialog(_j, o) {
      const nome = path.basename((o && o.defaultPath) || 'documento');
      const p = path.join(EXPORT, `${Date.now()}_${nome}`); registar(p, nome); return { canceled: false, filePath: p };
    },
    async showOpenDialog(_j, o) {
      if (o && (o.properties || []).includes('openDirectory')) { const p = path.join(EXPORT, `${Date.now()}_pasta`); fs.mkdirSync(p, { recursive: true }); pedido.pastas.push(p); return { canceled: false, filePaths: [p] }; }
      const u = pedido.uploads || []; return { canceled: !u.length, filePaths: u };
    },
  },
  shell: { async openExternal(url) { pedido.abrir.push(url); }, async openPath(p) { registar(p); return ''; } },
  app: { getPath: () => DADOS, getVersion: () => require('../../package.json').version },
  BrowserWindow: class {},
};
const orig = Module._load;
Module._load = function (req, ...r) { return req === 'electron' ? electron : orig.call(this, req, ...r); };

const dbm = require('../main/db'); dbm.init(DADOS);
const ipc = require('../main/ipc'); ipc.registarHandlers(() => null);
setInterval(() => { try { ipc.verificacaoAutomatica(); } catch (e) { dbm.log(null, 'erro', 'auto-verificação: ' + e.message); } }, 60000);

// ---------- HTTP ----------
const R = path.join(__dirname, '..', 'renderer');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png' };
const downloads = new Map(); // id -> { caminho, nome }
const corpo = async (rq, max) => { const p = []; let n = 0; for await (const c of rq) { n += c.length; if (n > max) throw new Error('Pedido demasiado grande.'); p.push(c); } return Buffer.concat(p); };
const json = (rs, o, st = 200) => { rs.statusCode = st; rs.setHeader('content-type', 'application/json; charset=utf-8'); rs.end(JSON.stringify(o)); };

function recolher() {
  const ficheiros = [];
  for (const dir of pedido.pastas) for (const f of fs.readdirSync(dir)) registar(path.join(dir, f), f);
  for (const [p, nome] of pedido.exportar) if (fs.existsSync(p) && fs.statSync(p).isFile()) {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8); downloads.set(id, { caminho: p, nome });
    ficheiros.push({ nome, url: `/download/${id}` });
  }
  return ficheiros;
}

const servidor = http.createServer(async (rq, rs) => {
  try {
    const url = rq.url.split('?')[0];
    if (rq.method === 'POST' && url === '/rpc') {
      const { canal, args, uploads } = JSON.parse((await corpo(rq, 5e6)).toString());
      const h = handlers['api:' + canal];
      if (!h) return json(rs, { ok: false, erro: 'Canal desconhecido: ' + canal });
      pedido = novoPedido((uploads || []).filter((p) => typeof p === 'string' && path.resolve(p).startsWith(UPLOADS)));
      const r = await h(null, ...(args || []));
      return json(rs, { ...r, ficheiros: recolher(), abrir: pedido.abrir });
    }
    if (rq.method === 'POST' && url === '/upload') {
      const nome = decodeURIComponent(String(rq.headers['x-nome'] || 'ficheiro')).replace(/[^\w.\-À-ÿ ]/g, '_');
      const p = path.join(UPLOADS, `${Date.now()}_${nome}`); fs.writeFileSync(p, await corpo(rq, 40e6));
      return json(rs, { caminho: p });
    }
    if (url.startsWith('/download/')) {
      const d = downloads.get(url.slice(10)); if (!d || !fs.existsSync(d.caminho)) { rs.statusCode = 404; return rs.end('Ficheiro expirado.'); }
      rs.setHeader('content-disposition', `attachment; filename*=UTF-8''${encodeURIComponent(d.nome)}`);
      rs.setHeader('content-type', 'application/octet-stream'); return fs.createReadStream(d.caminho).pipe(rs);
    }
    if (url === '/web-shim.js') { rs.setHeader('content-type', mime['.js']); return rs.end(fs.readFileSync(path.join(__dirname, 'web-shim.js'))); }
    const f = url === '/' ? '/index.html' : url; const p = path.join(R, f);
    if (!p.startsWith(R) || !fs.existsSync(p) || !fs.statSync(p).isFile()) { rs.statusCode = 404; return rs.end('não encontrado'); }
    let dados = fs.readFileSync(p);
    if (f === '/index.html') dados = Buffer.from(dados.toString().replace('<script src="core.js">', '<script src="/web-shim.js"></script>\n<script src="core.js">'));
    rs.setHeader('content-type', mime[path.extname(p)] || 'application/octet-stream'); rs.setHeader('cache-control', 'no-store'); rs.end(dados);
  } catch (e) { json(rs, { ok: false, erro: e.message }, 500); }
});
servidor.listen(PORTA, '0.0.0.0', () => console.log(`\nAulaPro (modo web de teste) a correr em http://localhost:${PORTA}\nDados guardados em: ${DADOS}\n`));
module.exports = { servidor, handlers };
