# AulaPro All-in-1 — Software para professores moçambicanos

Aplicação **desktop instalável** (não é site): Electron + SQLite local. Funciona 100% offline; sincroniza quando há internet.
Implementa os 9 módulos do *Documento Mestre V2.0* (documento principal) e as interfaces do PDF de design.

## Módulos
1. **Caderneta Mestra** — ACS1-3 + AT por trimestre, Regra A (padrão Sofala) / Regra B, média anual, exame (opção 1/2), cores (≥10 verde, 8–9,9 amarelo, <8 vermelho), pesquisa, validação 0–20, importação CSV, export PDF/CSV com timbre, simulador de exame (Premium).
2. **Plano de Aula Gerador** — texto, PDF (parser, até 25 MB), foto (OCR Tesseract, até 10 MB), TXT/DOCX, instrução “Como devo organizar?”, modelos da escola, 500 planos locais, edição, export PDF.
3. **Apresentação 1-Clique** — 3 a 10 slides a partir do plano, edição, modo “Apresentar”, export PPTX/PDF.
4. **Fichas e Testes** — múltipla escolha A–D, V/F, problemas; pontos; gabarito; auto-save 2 s; export PDF e DOCX; banco de questões (Premium).
5. **Biblioteca** — PDFs de licença aberta/domínio público; filtros; “Ler”; “Resumir para o plano”; fica disponível nos módulos 2 e 4; fontes abertas (BNM, OpenStax, UNESCO, Khan Academy).
6. **Assistente de Voz** — comando falado → plano (limites Grátis: 5 usos/mês, 1 min).
7. **Dashboard do Director** (plano Escola) — aprovação, média, desempenho por turma, alunos em risco, relatórios PDF/CSV.
8. **Central Offline** — estado de sincronização, armazenamento, backup local, exportar tudo, sincronização com servidor.
9. **Painel do Desenvolvedor** — login com palavra-passe mestra + **2FA (TOTP)**, KPIs, utilizadores, **fila de pagamentos com regra automática das 2 h**, números de pagamento, reclamações, chat, actualizações, logs (CSV).

Planos (Documento Mestre): Grátis · Semanal 99 MT · Mensal 299 MT · Anual 2.999 MT · Escola 5.000 MT/mês (até 30 professores). Marca de água grátis: “Gerado com AulaPro Grátis - aula.pro”.

## Gerar o instalador
Requisitos: Node.js 20+ e acesso ao npm.
```bash
npm install
# opcional, para OCR offline: coloque src/ocr/por.traineddata (ver src/ocr/LEIA-ME.txt)
npm start            # abre a aplicação para testar
npm test             # fórmulas, limites, segurança, pagamentos, admin
npm run dist:win     # Windows  -> dist/AulaPro Setup 1.0.0.exe (+ versão portátil)
npm run dist:mac     # macOS    -> dist/AulaPro-1.0.0.dmg   (compilar num Mac)
npm run dist:linux   # Linux    -> .AppImage e .deb (o .deb instala no Chrome OS via Linux/Crostini)
```
Sem instalar nada localmente: envie esta pasta para um repositório GitHub e execute o workflow **Gerar instaladores AulaPro** (separador Actions); os instaladores de Windows, macOS e Linux saem como artefactos.

## Versão Android (APK)
A mesma interface e os mesmos módulos corrêm no telemóvel (Capacitor + SQLite em WebAssembly, offline).
* No GitHub: **Actions → Gerar APK Android AulaPro → Run workflow**. No fim, descarregue o artefacto `AulaPro-Android-APK` (ficheiro `app-debug.apk`), copie para o telemóvel e instale (permita “instalar de fontes desconhecidas”).
* Localmente: `npm install`, `npm run mobile:build`, `npx cap add android`, `npx cap sync android`, e compile com Android Studio.
* Nesta primeira versão: PDF e foto (OCR) como material do Plano de Aula só no computador (no telemóvel use texto, TXT ou DOCX); o painel do desenvolvedor só no computador; as exportações abrem a janela “Partilhar/Guardar”.
* Os dados do telemóvel e do computador **não se sincronizam** até existir um servidor (ver abaixo).

## Primeira utilização
* Professores/directores criam conta no ecrã inicial (palavra-passe ≥ 6 caracteres e 1 símbolo; bloqueio de 15 min após 5 tentativas; sessão expira após 30 min de inactividade).
* **Desenvolvedor:** ecrã inicial → “Acesso do desenvolvedor” → criar administrador (mostra o segredo 2FA uma só vez; adicione ao Google Authenticator).
* Em **Números de pagamento** defina M-Pesa, E-Mola e o nome de confirmação (ex.: `AULAPRO-PAYMENTS-OFFICIAL`). Os utilizadores vêem os novos dados de imediato.
* IA: em **Números de pagamento → Sincronização e IA** pode ligar uma API compatível com OpenAI. Sem ela, o AulaPro usa o motor local (offline).

## Limitações conhecidas
* **Sem servidor central:** cada instalação (computador ou telemóvel) é independente. Os pagamentos enviados por um utilizador só chegam ao Painel do Desenvolvedor da *mesma* instalação; para o fluxo real (utilizador paga → desenvolvedor verifica noutro aparelho → Premium libertado) é preciso um servidor com contas, pagamentos e sincronização. É o passo seguinte recomendado.
* **Telemóveis:** Electron cobre Windows, macOS, Linux e Chrome OS (via .deb). Android/iOS exigem uma app móvel separada (ex.: Capacitor) que reutilize esta interface.
* **Voz:** usa o reconhecimento de voz do motor Chromium; pode exigir internet. Sem suporte, escreve-se o comando.
* **Pagamentos:** a verificação é por comprovativo + regras; não há ligação à API da M-Pesa/E-Mola.
* **Sincronização / actualizações automáticas:** requerem um servidor (`sync_url` e `build.publish.url` em `package.json`).
* Recuperação de palavra-passe: sem servidor de email, o código aparece no ecrã.
