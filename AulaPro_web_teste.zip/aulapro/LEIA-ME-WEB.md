# AulaPro — versão WEB de teste

Corre **todos os 9 módulos** no navegador, com os mesmos cálculos, limites Grátis/Premium, pagamentos e painel do desenvolvedor do programa final.
Serve só para testar antes de empacotar (Windows/Android).

## Abrir no GitHub (Codespaces — tem terminal)
1. Envie esta pasta para um repositório no GitHub (Add file → Upload files).
2. No repositório: botão verde **Code → Codespaces → Create codespace on main**.
3. No terminal que abrir em baixo, escreva:
   ```
   npm install --omit=dev
   npm run web
   ```
4. Aparece o aviso “Your application running on port 5177 is available” → **Open in Browser**.
   (Se desaparecer: separador **PORTAS** → linha 5177 → ícone do globo.)

Os dados ficam na pasta `dados-web/` do Codespace. Para recomeçar do zero apague essa pasta e reinicie.
Se o `npm install` queixar-se do `better-sqlite3`, escreva antes `nvm install 22 && nvm use 22` e repita.

## O que testar (checklist)
* **Conta:** criar conta (palavra-passe com ≥6 caracteres e 1 símbolo), sair, entrar, “Esqueci a palavra-passe”.
* **Caderneta:** criar turma, “Importar lista (CSV)” (uma coluna de nomes), lançar notas (0–20), ver cores, Regra A/B, exame, exportar CSV/PDF, pesquisar aluno.
* **Plano de Aula:** gerar com texto; carregar TXT/DOCX/PDF/foto (Premium); editar; guardar; exportar PDF; “Transformar em apresentação/ficha”.
* **Apresentação:** editar slides, “Apresentar” (setas ← → e Esc), exportar PPTX/PDF.
* **Fichas:** adicionar questões, auto-save, pré-visualização, gabarito, exportar PDF; DOCX só no Premium.
* **Biblioteca:** “Adicionar PDF”, filtros, “Resumir para o plano”, fontes abertas.
* **Voz:** no Chrome o microfone funciona (precisa de internet); também pode escrever o comando.
* **Planos/pagamento:** “Assinar” → enviar comprovativo (imagem).
* **Painel do desenvolvedor:** no ecrã inicial → “Acesso do desenvolvedor” → criar administrador (guarde o segredo 2FA no Google Authenticator) → Fila de pagamentos → **Verify** → o utilizador passa a Premium. Em “Números de pagamento” defina M-Pesa/E-Mola/nome de confirmação.
* **Dashboard do Director:** só plano Escola (atribua em Utilizadores → Plano → escola).

## Notas
* Uma pessoa de cada vez (a sessão é única no servidor). Não publique este servidor na internet.
* Em modo web, os ficheiros exportados descarregam para a pasta Transferências do navegador.
* Telemóvel: abra o endereço da porta 5177 no Chrome do telemóvel (porta pública temporária) para ver o ecrã adaptado.
